﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using mpl;
using System;

namespace mplExtension
{
    public abstract class LuaUITabCrossScene : LuaUIBaseCrossScene
    {
        private UITabBar tabBar;
        private UITabContent[] toggleContents;

        public int SelectedIndex
        {
            get { return tabBar.SelectedIndex; }
        }

        public override void Awake()
        {
            base.Awake();
            tabBar = GetComponentInChildren<UITabBar>(true);
            tabBar.Initialize(OnTabSelectedChanged);
            toggleContents = GetComponentsInChildren<UITabContent>(true);
        }

        protected virtual void Start()
        {
            if (tabBar.Length != toggleContents.Length)
            {
                throw new InvalidOperationException("Tab 和 TabContent数量不匹配");
            }
        }

        public override void OnEnable()
        {
            base.OnEnable();
            SetSelectedTabIndex(SelectedIndex);
        }

        public void SetSelectedTabIndex(int selectedIndex)
        {
            tabBar.SetSelectedIndex(selectedIndex);
            OnTabSelectedChanged(selectedIndex);
        }

        private void OnTabSelectedChanged(int index)
        {
            for (int i = 0; i < toggleContents.Length; i++)
            {
                if (i == index)
                {
                    toggleContents[i].Show();
                }
                else
                {
                    toggleContents[i].Hide();
                }
            }
        }
    }
}