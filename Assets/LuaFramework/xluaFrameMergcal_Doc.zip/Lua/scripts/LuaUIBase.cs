﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using mpl;
using System.IO;

namespace mplExtension
{
    public abstract class LuaUIBase : MonoBehaviourUIBase
    {
        protected mplExtension.LuaBehaviour luaBehaviour;

        public override void Awake()
        {
            base.Awake();
            luaBehaviour = Get<mplExtension.LuaBehaviour>(gameObject);
            luaBehaviour.SetLuaPath(GetLuaPath());
            luaBehaviour.SetInjection(RegistObj());
            luaBehaviour.InitLua(AfterAwakeInitLua());
            luaBehaviour.SetThis(GetThis());
        }
        public virtual MonoBehaviour GetThis()
        {
            return this;
        }
        public virtual string GetLuaRelativePath(string file)
        {
            string filetemp = file.Replace(".", "/");
            filetemp = Application.persistentDataPath + "/res/assets/" + filetemp + ".lua.txt";
            if (File.Exists(filetemp))
            {
                return "slua.net." + file.ToLower();
            }
            else
            {
                return "slua.local." + file.ToLower();
            }
        }
        public abstract string GetLuaPath();
        public abstract mplExtension.Injection[] RegistObj();
        public abstract object[] AfterAwakeInitLua();

        public override void MplOnOpen(object obj = null, params string[] param)
        {
            base.MplOnOpen(obj, param);
            luaBehaviour.MplOnOpen(obj, param);
        }
        public override void MplOnOpenEnd()
        {
            base.MplOnOpenEnd();
            luaBehaviour.MplOnOpenEnd();
        }

        public override void MplOnCloseEnd()
        {
            base.MplOnCloseEnd();
            luaBehaviour.MplOnCloseEnd();
        }

        public override object MplOnClose()
        {
            return luaBehaviour.MplOnClose();
        }

        public override void MplOnlanguageChange(string type)
        {
            base.MplOnlanguageChange(type);
            luaBehaviour.MplOnlanguageChange(type);
        }

        public override void MplRefresh()
        {
            base.MplRefresh();
            luaBehaviour.MplRefresh();
        }
    }
}