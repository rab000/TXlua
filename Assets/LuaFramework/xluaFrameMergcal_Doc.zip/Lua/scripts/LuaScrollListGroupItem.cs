﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace mplExtension
{
    public class LuaScrollListGroupItem<T> : MonoBehaviour
    {
        [SerializeField]
        private UIScrollListItem<T>[] subItems;
        public UIScrollListItem<T>[] SubItems
        {
            get
            {
                if (subItems == null)
                {
                    subItems = GetComponentsInChildren<UIScrollListItem<T>>(true);
                }
                return subItems;
            }
        }
    }
}
