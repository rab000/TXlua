﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using mpl;
using System.IO;

namespace mplExtension
{
    public abstract class LuaBase : MonoBehaviourBase
    {
        private mplExtension.LuaBehaviour luaBehaviour;

        public virtual void Awake()
        {
            luaBehaviour = Get<mplExtension.LuaBehaviour>(gameObject);
            luaBehaviour.SetLuaPath(GetLuaPath());
            luaBehaviour.SetInjection(RegistObj());
            luaBehaviour.InitLua(AfterAwakeInitLua());
            luaBehaviour.SetThis(GetThis());
        }

        public virtual MonoBehaviour GetThis()
        {
            return this;
        }
        public abstract string GetLuaPath();
        public virtual string GetLuaRelativePath(string file)
        {
            string filetemp = file.Replace(".", "/");
            filetemp = Application.persistentDataPath + "/res/assets/" + filetemp + ".lua.txt";
            if (File.Exists(filetemp))
            {
                return "slua.net." + file.ToLower();
            }
            else
            {
                return "slua.local." + file.ToLower();
            }
        }
        public abstract mplExtension.Injection[] RegistObj();
        public abstract object[] AfterAwakeInitLua();

        public override void MplOnlanguageChange(string type)
        {
            base.MplOnlanguageChange(type);
            luaBehaviour.MplOnlanguageChange(type);
        }

        public override void MplRefresh()
        {
            base.MplRefresh();
            luaBehaviour.MplRefresh();
        }
    }
}