﻿---@class UnityEngine.UI.Toggle.ToggleEvent : UnityEngine.Events.UnityEvent<bool>
local m = {}
return m
