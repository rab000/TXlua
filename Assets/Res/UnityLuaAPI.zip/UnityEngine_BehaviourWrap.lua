﻿---@class UnityEngine.Behaviour : UnityEngine.Component
---@field public enabled System.Boolean
---@field public isActiveAndEnabled System.Boolean
local m = {}
return m
