﻿---@class UnityEngine.Projector : UnityEngine.Behaviour
---@field public nearClipPlane System.Single
---@field public farClipPlane System.Single
---@field public fieldOfView System.Single
---@field public aspectRatio System.Single
---@field public orthographic System.Boolean
---@field public orthographicSize System.Single
---@field public ignoreLayers System.Int32
---@field public material UnityEngine.Material
local m = {}
return m
