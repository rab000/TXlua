﻿---@class UnityEngine.UI.InputField.SubmitEvent : UnityEngine.Events.UnityEvent<string>
local m = {}
return m
