﻿---@class UnityEngine.UI.BaseMeshEffect : UnityEngine.EventSystems.UIBehaviour
local m = {}
---@param mesh UnityEngine.Mesh
function m:ModifyMesh(mesh) end
return m
