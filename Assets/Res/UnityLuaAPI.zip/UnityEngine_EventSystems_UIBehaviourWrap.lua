﻿---@class UnityEngine.EventSystems.UIBehaviour : UnityEngine.MonoBehaviour
local m = {}
---@return System.Boolean
function m:IsActive() end
---@return System.Boolean
function m:IsDestroyed() end
return m
