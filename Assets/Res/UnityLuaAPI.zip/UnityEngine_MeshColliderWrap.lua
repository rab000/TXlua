﻿---@class UnityEngine.MeshCollider : UnityEngine.Collider
---@field public sharedMesh UnityEngine.Mesh
---@field public convex System.Boolean
---@field public inflateMesh System.Boolean
---@field public skinWidth System.Single
local m = {}
return m
