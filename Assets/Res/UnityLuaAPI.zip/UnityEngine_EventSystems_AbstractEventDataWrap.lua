﻿---@class UnityEngine.EventSystems.AbstractEventData : System.Object
---@field public used System.Boolean
local m = {}
function m:Reset() end
function m:Use() end
return m
