﻿---@class UnityEngine.UI.Outline : UnityEngine.UI.Shadow
local m = {}
---@param vh UnityEngine.UI.VertexHelper
function m:ModifyMesh(vh) end
return m
