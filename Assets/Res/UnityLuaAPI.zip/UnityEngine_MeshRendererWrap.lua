﻿---@class UnityEngine.MeshRenderer : UnityEngine.Renderer
---@field public additionalVertexStreams UnityEngine.Mesh
local m = {}
return m
