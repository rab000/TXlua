﻿---@class UnityEngine.UI.RawImage : UnityEngine.UI.MaskableGraphic
---@field public mainTexture UnityEngine.Texture
---@field public texture UnityEngine.Texture
---@field public uvRect UnityEngine.Rect
local m = {}
function m:SetNativeSize() end
return m
