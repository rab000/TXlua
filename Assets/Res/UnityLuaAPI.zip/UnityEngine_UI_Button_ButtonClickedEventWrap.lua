﻿---@class UnityEngine.UI.Button.ButtonClickedEvent : UnityEngine.Events.UnityEvent
local m = {}
return m
