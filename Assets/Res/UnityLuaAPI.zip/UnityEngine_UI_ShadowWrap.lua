﻿---@class UnityEngine.UI.Shadow : UnityEngine.UI.BaseMeshEffect
---@field public effectColor UnityEngine.Color
---@field public effectDistance UnityEngine.Vector2
---@field public useGraphicAlpha System.Boolean
local m = {}
---@param vh UnityEngine.UI.VertexHelper
function m:ModifyMesh(vh) end
return m
