﻿---@class UnityEngine.UI.Slider.SliderEvent : UnityEngine.Events.UnityEvent<float>
local m = {}
return m
