﻿---@class UnityEngine.SleepTimeout : System.Object
---@field public NeverSleep System.Int32
---@field public SystemSetting System.Int32
local m = {}
return m
