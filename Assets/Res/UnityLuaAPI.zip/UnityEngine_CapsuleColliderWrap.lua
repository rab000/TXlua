﻿---@class UnityEngine.CapsuleCollider : UnityEngine.Collider
---@field public center UnityEngine.Vector3
---@field public radius System.Single
---@field public height System.Single
---@field public direction System.Int32
local m = {}
return m
