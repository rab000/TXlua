﻿---@class UnityEngine.EventSystems.BaseEventData : UnityEngine.EventSystems.AbstractEventData
---@field public currentInputModule UnityEngine.EventSystems.BaseInputModule
---@field public selectedObject UnityEngine.GameObject
local m = {}
return m
