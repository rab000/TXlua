﻿---@class UnityEngine.SphereCollider : UnityEngine.Collider
---@field public center UnityEngine.Vector3
---@field public radius System.Single
local m = {}
return m
