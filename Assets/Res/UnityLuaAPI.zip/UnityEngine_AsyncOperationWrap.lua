﻿---@class UnityEngine.AsyncOperation : System.Object
---@field public isDone System.Boolean
---@field public progress System.Single
---@field public priority System.Int32
---@field public allowSceneActivation System.Boolean
local m = {}
return m
