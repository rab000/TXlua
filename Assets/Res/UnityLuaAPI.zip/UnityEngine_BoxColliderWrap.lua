﻿---@class UnityEngine.BoxCollider : UnityEngine.Collider
---@field public center UnityEngine.Vector3
---@field public size UnityEngine.Vector3
local m = {}
return m
