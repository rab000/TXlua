﻿---@class UnityEngine.ScriptableObject : UnityEngine.Object
local m = {}
---@param className System.String
---@return UnityEngine.ScriptableObject
function m.CreateInstance(className) end
return m
